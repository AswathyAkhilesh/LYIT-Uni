<?php include ('header.php'); ?>


<section Class="container spad">

    
    <div class="panel panel-info" style = "padding-top: 50px">
        <div class="panel-heading">
            <h3 class="panel-title" style = "text-align: center">Applicant Information</h3>
        </div>

        <div class="panel-body">
            <div class="row">
            <div class="col-md-1 col-md-1 ">  </div>
                
                
            <div class=" col-md-9 col-lg-12 " style = "padding-top: 30px"> 
            <table class="table table-user-information">
                <thead>
                    <h4 style = "padding-left: 10px">Personal Details<h4>
                </thead>
                <tbody>
                    <tr>
                        <td>First Name:</td>
                        <td>Matthew</td>
                    </tr>
                    <tr>
                        <td>Surname:</td>
                        <td>Bergin</td>
                    </tr>
                    <tr>
                        <td>Date of Birth:</td>
                        <td>15/09/1992</td>
                    </tr>
                    <tr>
                        <td>Identify as:</td>
                        <td>Male</td>
                    </tr>
                    <tr>
                        <td>Address 1:</td>
                        <td>123 Fake street</td>
                    </tr>
                    <tr>
                        <td>Address 2:</td>
                        <td>Fake Place</td>
                    </tr>
                    <tr>
                        <td>County:</td>
                        <td>Donegal</td>
                    </tr>
                    <tr>
                        <td>Country:</td>
                        <td>Ireland</td>
                    </tr>
                    <tr>
                        <td>Email:</td>
                        <td><a href="mailto:email@email.com">email@email.com</a></td>
                    </tr>
                        <td>Phone Number:</td>
                        <td>123456789</td>     
                    </tr>
                     
                    </tbody>
                    </table>

                
                <table class="table table-user-information">
                <thead>
                    <h4 style = "padding-left: 10px">Application Details<h4>
                </thead>
                <tbody>
                    <tr>
                        <td>Applied Course:</td>
                        <td>Cloud Technology</td>
                    </tr>
                    <tr>
                        <td>Qualifications:</td>
                        <td>PhD in something at Letterkenny Institute of Technology</td>
                    </tr>
                    <tr>
                        <td>Degree Classification:</td>
                        <td>2.1</td>
                    </tr>
                    <tr>
                        <td>Work Experience:</td>
                        <td>5 years in retail. 2 years in computing.</td>
                    </tr>
                    
                    
                </tbody>
                </table>

					<a href="applicantlist.php" class="site-btn text-white">Schedule Interview</a>

            

        </section>

<script>


</script>

<?php include ('footer.php'); ?>