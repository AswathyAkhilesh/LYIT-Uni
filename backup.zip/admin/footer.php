	<!-- Footer section -->
	<footer id="contact" class="footer-section">
		<!-- copyright -->
		<div class="copyright">
			<div class="container"><p>
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://lyit.ie" target="_blank">LYIT.edu</a> | Support</p>
			</div>
		</div>
	</footer>
	<!-- Footer section end-->

	<!-- Return to Top -->
	<a href="javascript:" id="top"><i class="fa fa-angle-up"></i></a>

	<!--====== Javascripts & Jquery ======-->
	<!-- <script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.countdown.js"></script>
	<script src="js/masonry.pkgd.min.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/main.js"></script> -->
	<script src="../js/tools.js"></script>
	
</body>
</html>